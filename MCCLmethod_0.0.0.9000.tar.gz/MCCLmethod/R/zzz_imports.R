#' @importFrom stats na.omit nlm
NULL
