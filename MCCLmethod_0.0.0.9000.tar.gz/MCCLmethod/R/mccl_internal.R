# internal helpers --------------------------------------------------------

#' Log-partial likelihood for nested case-control (1-D covariate)
#' @keywords internal
NCClike <- function(beta, dat, selected) {
  ll <- 0
  for (i in seq_len(nrow(selected))) {
    idx <- na.omit(selected[i, ])
    z   <- dat[idx, 3]              # current covariate
    ll  <- ll + beta * z[1] - log(sum(exp(beta * z)))
  }
  -ll
}

#' Score function (first derivative) of NCClike
#' @keywords internal
PNCClike <- function(beta, dat, selected) {
  sc <- 0
  for (i in seq_len(nrow(selected))) {
    idx <- na.omit(selected[i, ])
    z   <- dat[idx, 3]
    sc  <- sc + z[1] -
      crossprod(z, exp(beta * z)) / sum(exp(beta * z))
  }
  -sc
}

#' Observed information (second derivative) of NCClike
#' @keywords internal
HNCClike <- function(beta, dat, selected) {
  info <- 0
  for (i in seq_len(nrow(selected))) {
    idx <- na.omit(selected[i, ])
    z   <- dat[idx, 3]
    num <- crossprod(z, exp(beta * z))
    info <- info +
      num^2 / sum(exp(beta * z))^2 -
      crossprod(z^2, exp(beta * z)) / sum(exp(beta * z))
  }
  -info
}
