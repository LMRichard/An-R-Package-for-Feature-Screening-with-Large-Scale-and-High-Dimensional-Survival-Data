#' Pair each case with \code{Ncontr} matched controls
#'
#' @param dat A numeric matrix or data frame; first column = survival time,
#'   second column = event indicator (1 = event, 0 = censor),
#'   remaining columns = covariates.
#' @param Ncontr Integer. How many controls to match to each case.
#'
#' @return An integer matrix whose first column contains case indices and
#'   follow-up columns contain indices of matched controls (NA if < Ncontr
#'   eligible controls exist).
#' @export
ContSet <- function(dat, Ncontr = 10) {
  idx   <- seq_len(nrow(dat))
  cases <- idx[dat[, 2] == 1]
  # sort cases by decreasing survival time (longest follow-up first)
  order_cases <- sort.int(dat[cases, 1], decreasing = TRUE, index.return = TRUE)$ix
  
  picked <- integer(nrow(dat)); picked[cases] <- 1
  out    <- NULL
  
  for (i in order_cases) {
    pool <- idx[dat[, 1] >= dat[cases[i], 1] & dat[, 2] == 0 & picked == 0]
    
    sel <- if (length(pool) > 1) {
      sample(pool)[1:Ncontr]
    } else if (length(pool) == 1) {
      c(pool, rep(NA, Ncontr - 1))
    } else {
      rep(NA, Ncontr)
    }
    
    out    <- rbind(out, c(cases[i], sel))
    picked[sel[!is.na(sel)]] <- 1
  }
  
  out
}

#' Compute Wald-type MCCL statistic for one covariate
#'
#' @param vec Numeric vector – the covariate under test (length = \code{nrow(response)})
#' @param response Two-column matrix: survival time and event indicator.
#' @param selected Output from \code{ContSet()} – rows = cases; columns = matched controls.
#'
#' @return Absolute Wald statistic |beta_hat / SE(beta_hat)|.
#' @examples
#' ## toy demo
#' set.seed(1)
#' dat <- cbind(time = rexp(50, 0.1),
#'              status = rbinom(50, 1, 0.4),
#'              X1 = rnorm(50))
#' sel <- ContSet(dat, Ncontr = 2)
#' vecNCC(dat[, 3], dat[, 1:2], sel)
#' @export
vecNCC <- function(vec,
                   response,
                   selected) {
  
  stopifnot(ncol(response) == 2,
            length(vec) == nrow(response))
  
  fit <- nlm(f       = NCClike,
             p       = 0,
             hessian = TRUE,
             dat     = cbind(response, vec),
             selected = selected)
  
  abs(drop(fit$estimate) * sqrt(fit$hessian))
}
